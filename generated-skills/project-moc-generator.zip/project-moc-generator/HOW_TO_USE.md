# How to Use the Project MOC Generator Skill

Hey Claude—I just added the "project-moc-generator" skill. Can you generate comprehensive project documentation for this codebase?

## Example Invocations

### Example 1: Complete Project Documentation
```
Hey Claude—I just added the "project-moc-generator" skill. Can you generate a complete project MOC including features, architecture decisions, and component maps?
```

**What you'll get:**
- Full `docs/` folder structure
- PROJECT_MOC.md as entry point
- Feature documentation with implementation details
- Architecture decision log
- Component maps with source code links
- All using GitHub-compatible markdown links

---

### Example 2: Feature Documentation Only
```
Hey Claude—I just added the "project-moc-generator" skill. Can you analyze the implemented features and create feature-specific MOCs?
```

**What you'll get:**
- `docs/features/FEATURES_MOC.md` overview
- Individual feature documentation files
- Links to implementing components
- Current capabilities (not future plans)

---

### Example 3: Architecture and Decisions
```
Hey Claude—I just added the "project-moc-generator" skill. Can you document the architectural decisions including what we considered but didn't implement?
```

**What you'll get:**
- `docs/architecture/decisions.md` with decision history
- Technology choice documentation
- "Roads not taken" with reasoning
- Links to affected components

---

### Example 4: Component Mapping
```
Hey Claude—I just added the "project-moc-generator" skill. Can you create detailed component maps linking to source code?
```

**What you'll get:**
- `docs/components/COMPONENTS_MOC.md` overview
- Individual component documentation
- Source code file links
- Dependency graphs
- Implementation patterns

---

### Example 5: Update Existing Documentation
```
Hey Claude—I just added the "project-moc-generator" skill. I've added new features since last documentation. Can you update the project MOC?
```

**What you'll get:**
- Updated MOC files with new content
- Refreshed `last_updated` dates in frontmatter
- New feature and component documentation
- Preserved existing custom content where possible

---

### Example 6: Devlog Synthesis
```
Hey Claude—I just added the "project-moc-generator" skill. Can you read through docs/devlog/ and synthesize the project evolution into structured documentation?
```

**What you'll get:**
- Analysis of devlog entries for context
- Decision rationale extracted from notes
- Project evolution narrative
- Integrated insights into MOC structure

---

## What to Provide

### Essential
- Access to your project codebase
- `docs/` folder (skill will create if needed)

### Recommended
- `docs/devlog/` with ongoing notes, decisions, thoughts
- Existing README or project documentation
- Package configuration (package.json, requirements.txt, etc.)

### Optional (improves output)
- Architecture diagrams or notes
- CHANGELOG or version history
- Code comments explaining complex decisions

## What You'll Get

### Documentation Structure
```
docs/
├── PROJECT_MOC.md              # Your starting point
├── features/
│   ├── FEATURES_MOC.md         # Feature overview
│   └── feature-name.md         # Individual features
├── architecture/
│   ├── ARCHITECTURE_MOC.md     # Architecture overview
│   ├── decisions.md            # ADRs and decision log
│   └── tech-stack.md           # Tech choices
├── components/
│   ├── COMPONENTS_MOC.md       # Component overview
│   └── component-name.md       # Individual components
└── devlog/
    └── your-notes.md           # Analyzed, not modified
```

### Every Document Includes
- YAML frontmatter with dates
- Standard markdown links (GitHub-compatible)
- Links to source code
- Current implementation state
- Navigation to related docs

### Link Format
All links use standard markdown:
```markdown
[Feature Name](./features/auth-system.md)
[Source Code](../src/auth/index.ts)
[Architecture Decision](./architecture/decisions.md#use-jwt-tokens)
```

NO wiki-links (`[[like this]]`) - ensures GitHub rendering works perfectly.

## Usage Patterns

### Pattern 1: Initial Documentation
First time documenting your project:

```
@project-moc-generator Generate complete project documentation from scratch
```

Review output, add human insights, commit to git.

---

### Pattern 2: Regular Updates
After completing feature work:

```
@project-moc-generator Update project MOC with latest changes
```

Quick refresh to keep docs current.

---

### Pattern 3: Decision Capture
After making architectural decisions:

```
@project-moc-generator Document the decision to use [technology X] and what alternatives we considered
```

Captures context while fresh in mind.

---

### Pattern 4: Onboarding Documentation
Preparing for new team member:

```
@project-moc-generator Generate comprehensive onboarding documentation showing all features and components
```

Creates entry point for understanding entire project.

---

### Pattern 5: Stakeholder Reports
Creating documentation for non-technical stakeholders:

```
@project-moc-generator Generate high-level project overview suitable for stakeholders showing implemented features
```

Focus on capabilities and decisions, less on code internals.

---

## Tips for Best Results

1. **Maintain a devlog**: Keep `docs/devlog/` updated with thoughts, decisions, and context as you work. The skill analyzes these for richer documentation.

2. **Run after milestones**: Generate documentation after completing features or making architectural changes while context is fresh.

3. **Review and enhance**: Generated docs are comprehensive but benefit from human refinement—add examples, diagrams, and insights.

4. **Keep organized**: The skill outputs to `docs/` following a clear structure. Maintain this organization for consistency.

5. **Link from README**: Add link to `docs/PROJECT_MOC.md` from your main README so it's discoverable.

6. **Commit with code**: Treat documentation changes like code—review, commit, and track in git.

7. **Use specific requests**: Instead of "document everything", ask for specific areas: "document the auth feature" or "create component map for API services".

## Integration with Workflow

### During Development
```
# Keep notes as you work
echo "Decided to use JWT instead of sessions because..." > docs/devlog/2025-11-20-auth-decision.md

# After completing feature
@project-moc-generator Update project MOC with auth feature
```

### Before Code Review
```
# Generate docs showing what changed
@project-moc-generator Document the new features in this branch

# Review generated docs alongside code
git diff docs/
```

### For Releases
```
# Document state at release
@project-moc-generator Generate complete project documentation for v2.0

# Include in release artifacts
git add docs/
git commit -m "docs: update MOC for v2.0 release"
```

## Common Questions

**Q: Will this modify my source code?**
A: No. The skill only reads source code and writes to `docs/` folder. Your code is never modified.

**Q: What if I already have docs/ folder?**
A: The skill integrates with existing documentation. It won't overwrite your custom content but will create new MOC structure alongside it.

**Q: Do I need docs/devlog/?**
A: No, it's optional. But having ongoing notes there provides valuable context for better documentation generation.

**Q: Will it work on GitHub?**
A: Yes! All links use standard markdown format `[text](path)` that renders perfectly on GitHub, GitLab, and other platforms.

**Q: Can I customize the output?**
A: Yes. Generated docs are starting points. Edit them, add diagrams, include examples, and commit the enhanced versions.

**Q: How often should I regenerate?**
A: After significant changes: new features, architectural decisions, component additions. Treat it like updating your README—do it when there's something meaningful to document.

---

## Next Steps

1. **Install the skill** using one of the methods in README.md
2. **Navigate to your project** directory
3. **Invoke with**: `@project-moc-generator Generate complete project MOC`
4. **Review the output** in `docs/` folder
5. **Enhance with human insights** as needed
6. **Commit to git** alongside your code
7. **Share with team** by linking from main README

Start with a complete generation, then use targeted updates as you continue development. Your documentation will stay current with minimal effort!
