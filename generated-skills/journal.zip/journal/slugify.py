"""
Slug generation module for interstitial journal skill.
Creates URL-friendly slugs from text for journal filenames.
"""

import re
import unicodedata
from typing import Optional


def slugify(text: str, max_length: int = 50) -> str:
    """
    Convert text to a URL-friendly slug.

    Args:
        text: Input text to slugify
        max_length: Maximum length of slug (default: 50)

    Returns:
        Slugified string suitable for filenames

    Examples:
        >>> slugify("Building Agent Composition System")
        'building-agent-composition-system'

        >>> slugify("Storage Decision: SwiftData vs CoreData")
        'storage-decision-swiftdata-vs-coredata'

        >>> slugify("Multiple    Spaces   &  Special!!  Chars")
        'multiple-spaces-special-chars'
    """
    # Convert to ASCII, removing accents
    text = unicodedata.normalize('NFKD', text)
    text = text.encode('ascii', 'ignore').decode('ascii')

    # Convert to lowercase
    text = text.lower()

    # Remove special characters, keep only alphanumeric, spaces, and hyphens
    text = re.sub(r'[^a-z0-9\s-]', '', text)

    # Replace multiple spaces/hyphens with single hyphen
    text = re.sub(r'[\s-]+', '-', text)

    # Remove leading/trailing hyphens
    text = text.strip('-')

    # Truncate to max length at word boundary if possible
    if len(text) > max_length:
        text = text[:max_length]
        # Try to cut at last hyphen to avoid cutting words
        last_hyphen = text.rfind('-')
        if last_hyphen > max_length * 0.7:  # If hyphen is in last 30%
            text = text[:last_hyphen]

    return text or 'journal-entry'  # Fallback if empty


def generate_filename_slug(
    text: str,
    date_prefix: Optional[str] = None,
    time_prefix: Optional[str] = None,
    max_slug_length: int = 50
) -> str:
    """
    Generate a complete filename with date/time prefix and slug.

    Args:
        text: Text to use for slug generation
        date_prefix: Date prefix (e.g., "2025-11-20"), auto-generated if None
        time_prefix: Time prefix (e.g., "1423"), auto-generated if None
        max_slug_length: Maximum length of the slug portion

    Returns:
        Complete filename like "2025-11-20-1423-slug.md"

    Examples:
        >>> generate_filename_slug("Building Agent System")
        '2025-11-20-1423-building-agent-system.md'

        >>> generate_filename_slug("Bug Fix", "2025-11-19", "0930")
        '2025-11-19-0930-bug-fix.md'
    """
    from datetime import datetime

    # Generate date/time if not provided
    if date_prefix is None:
        date_prefix = datetime.now().strftime('%Y-%m-%d')

    if time_prefix is None:
        time_prefix = datetime.now().strftime('%H%M')

    # Generate slug from text
    slug = slugify(text, max_length=max_slug_length)

    return f"{date_prefix}-{time_prefix}-{slug}.md"


def extract_slug_from_summary(summary: str, max_length: int = 50) -> str:
    """
    Extract a good slug from a summary or title.

    Tries to use the most meaningful words from the beginning.

    Args:
        summary: Summary or title text
        max_length: Maximum slug length

    Returns:
        Slugified text

    Examples:
        >>> extract_slug_from_summary("We built a multi-agent system...")
        'we-built-multi-agent-system'

        >>> extract_slug_from_summary("Fixed critical bug in auth module")
        'fixed-critical-bug-in-auth-module'
    """
    # Take first sentence or first 100 chars
    if '.' in summary:
        first_sentence = summary.split('.')[0]
    else:
        first_sentence = summary[:100]

    return slugify(first_sentence, max_length=max_length)
