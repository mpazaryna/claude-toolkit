"""
Git analysis module for interstitial journal skill.
Extracts commit history, changed files, and diffs from git repositories.
"""

import subprocess
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta


class GitAnalyzer:
    """Analyze git history and changes for journal context."""

    def __init__(self, workspace_path: str = ".", time_window_hours: int = 2):
        """
        Initialize git analyzer.

        Args:
            workspace_path: Path to git repository
            time_window_hours: How far back to look for commits
        """
        self.workspace_path = Path(workspace_path).resolve()
        self.time_window_hours = time_window_hours
        self.cutoff_time = datetime.now() - timedelta(hours=time_window_hours)

    def get_recent_commits(self) -> List[Dict[str, str]]:
        """
        Get commits within the time window.

        Returns:
            List of commit dicts with hash, message, author, date
        """
        since_time = self.cutoff_time.strftime('%Y-%m-%d %H:%M:%S')

        try:
            # Get commit log with custom format
            result = subprocess.run(
                [
                    'git', 'log',
                    f'--since={since_time}',
                    '--pretty=format:%H|%s|%an|%ai'
                ],
                cwd=self.workspace_path,
                capture_output=True,
                text=True,
                timeout=10
            )

            if result.returncode != 0 or not result.stdout.strip():
                return []

            commits = []
            for line in result.stdout.strip().split('\n'):
                if not line:
                    continue

                parts = line.split('|', 3)
                if len(parts) == 4:
                    commits.append({
                        'hash': parts[0][:7],  # Short hash
                        'message': parts[1],
                        'author': parts[2],
                        'date': parts[3]
                    })

            return commits

        except (subprocess.SubprocessError, FileNotFoundError):
            return []

    def get_changed_files(self) -> List[str]:
        """
        Get list of files changed in recent commits.

        Returns:
            List of file paths
        """
        since_time = self.cutoff_time.strftime('%Y-%m-%d %H:%M:%S')

        try:
            result = subprocess.run(
                [
                    'git', 'log',
                    f'--since={since_time}',
                    '--name-only',
                    '--pretty=format:'
                ],
                cwd=self.workspace_path,
                capture_output=True,
                text=True,
                timeout=10
            )

            if result.returncode != 0:
                return []

            # Get unique files, filter empty lines
            files = set()
            for line in result.stdout.split('\n'):
                line = line.strip()
                if line:
                    files.add(line)

            return sorted(list(files))

        except (subprocess.SubprocessError, FileNotFoundError):
            return []

    def get_file_stats(self) -> Dict[str, int]:
        """
        Get statistics about changes (insertions, deletions).

        Returns:
            Dict with files_changed, insertions, deletions
        """
        since_time = self.cutoff_time.strftime('%Y-%m-%d %H:%M:%S')

        try:
            result = subprocess.run(
                [
                    'git', 'log',
                    f'--since={since_time}',
                    '--numstat',
                    '--pretty=format:'
                ],
                cwd=self.workspace_path,
                capture_output=True,
                text=True,
                timeout=10
            )

            if result.returncode != 0:
                return {'files_changed': 0, 'insertions': 0, 'deletions': 0}

            insertions = 0
            deletions = 0
            files = set()

            for line in result.stdout.split('\n'):
                line = line.strip()
                if not line:
                    continue

                parts = line.split('\t')
                if len(parts) >= 3:
                    try:
                        ins = int(parts[0]) if parts[0].isdigit() else 0
                        dels = int(parts[1]) if parts[1].isdigit() else 0
                        insertions += ins
                        deletions += dels
                        files.add(parts[2])
                    except (ValueError, IndexError):
                        continue

            return {
                'files_changed': len(files),
                'insertions': insertions,
                'deletions': deletions
            }

        except (subprocess.SubprocessError, FileNotFoundError):
            return {'files_changed': 0, 'insertions': 0, 'deletions': 0}

    def get_current_branch(self) -> str:
        """Get current git branch name."""
        try:
            result = subprocess.run(
                ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
                cwd=self.workspace_path,
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode == 0:
                return result.stdout.strip()
            return 'unknown'

        except (subprocess.SubprocessError, FileNotFoundError):
            return 'unknown'

    def analyze(self) -> Dict[str, Any]:
        """
        Perform complete git analysis.

        Returns:
            Dict with commits, files, stats, and branch info
        """
        commits = self.get_recent_commits()
        changed_files = self.get_changed_files()
        stats = self.get_file_stats()
        branch = self.get_current_branch()

        return {
            'commits': commits,
            'changed_files': changed_files,
            'stats': stats,
            'branch': branch,
            'commit_count': len(commits)
        }
