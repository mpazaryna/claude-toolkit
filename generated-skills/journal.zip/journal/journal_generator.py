"""
Journal generation module for interstitial journal skill.
Handles interactive prompting and markdown generation.
"""

from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
from .slugify import generate_filename_slug, extract_slug_from_summary


class JournalGenerator:
    """Generate comprehensive journal entries from context and user input."""

    def __init__(self, workspace_path: str = "."):
        """
        Initialize journal generator.

        Args:
            workspace_path: Path to workspace directory
        """
        self.workspace_path = Path(workspace_path).resolve()
        self.journal_dir = self.workspace_path / "docs" / "journal"

    def ensure_journal_dir(self) -> None:
        """Create journal directory if it doesn't exist."""
        self.journal_dir.mkdir(parents=True, exist_ok=True)

    def format_git_section(self, git_analysis: Dict[str, Any]) -> str:
        """
        Format git analysis into markdown section.

        Args:
            git_analysis: Dict from GitAnalyzer.analyze()

        Returns:
            Formatted markdown string
        """
        lines = ["## What Changed\n"]

        # Branch info
        lines.append(f"**Branch**: `{git_analysis['branch']}`\n")

        # Stats
        stats = git_analysis['stats']
        lines.append(f"**Summary**: {git_analysis['commit_count']} commits, "
                    f"{stats['files_changed']} files changed, "
                    f"+{stats['insertions']}/-{stats['deletions']} lines\n")

        # Commits
        if git_analysis['commits']:
            lines.append("### Commits\n")
            for commit in git_analysis['commits']:
                lines.append(f"- `{commit['hash']}`: {commit['message']}")
                lines.append(f"  - *{commit['author']}* - {commit['date']}\n")

        # Changed files
        if git_analysis['changed_files']:
            lines.append("### Files Modified\n")
            for file_path in git_analysis['changed_files']:
                lines.append(f"- `{file_path}`")
            lines.append("")

        return "\n".join(lines)

    def format_filesystem_section(self, fs_analysis: Dict[str, Any]) -> str:
        """
        Format filesystem analysis into markdown section.

        Args:
            fs_analysis: Dict from FilesystemAnalyzer.analyze()

        Returns:
            Formatted markdown string
        """
        lines = ["## What Changed\n"]

        stats = fs_analysis['stats']
        lines.append(f"**Summary**: {stats['total_files']} files modified "
                    f"({stats['total_size_bytes']:,} bytes)\n")

        # Files grouped by type
        if fs_analysis['grouped_by_type']:
            lines.append("### Files Modified (by type)\n")
            for file_type, paths in sorted(fs_analysis['grouped_by_type'].items()):
                lines.append(f"**{file_type.capitalize()}**:")
                for path in paths:
                    lines.append(f"- `{path}`")
                lines.append("")

        # Detailed file list
        if fs_analysis['files']:
            lines.append("### Detailed Changes\n")
            for file_info in fs_analysis['files'][:20]:  # Limit to 20 files
                lines.append(f"- `{file_info['path']}` "
                           f"({file_info['size_bytes']:,} bytes, "
                           f"modified: {file_info['modified']})")
            lines.append("")

        return "\n".join(lines)

    def generate_journal_entry(
        self,
        context: Dict[str, Any],
        user_responses: Dict[str, str],
        analysis: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Generate complete journal entry markdown.

        Args:
            context: Context dict from ContextDetector
            user_responses: User answers to prompts
            analysis: Git or filesystem analysis results

        Returns:
            Complete markdown journal entry
        """
        lines = []

        # Title and metadata
        title = user_responses.get('title', 'Work Session')
        lines.append(f"# {title}\n")

        now = datetime.now()
        lines.append(f"**Date**: {now.strftime('%Y-%m-%d')}")
        lines.append(f"**Time**: {now.strftime('%H:%M')}")
        lines.append(f"**Type**: {user_responses.get('work_type', 'Development')}")
        lines.append("")
        lines.append("---\n")

        # Executive Summary
        if 'summary' in user_responses:
            lines.append("## Executive Summary\n")
            lines.append(user_responses['summary'])
            lines.append("")

        # What Changed section (from git or filesystem)
        if analysis:
            if context['mode'] == 'git':
                lines.append(self.format_git_section(analysis))
            elif context['mode'] == 'filesystem':
                lines.append(self.format_filesystem_section(analysis))

        # The Problem
        if 'problem' in user_responses:
            lines.append("## The Problem\n")
            lines.append(user_responses['problem'])
            lines.append("")

        # Approach Taken
        if 'approach' in user_responses:
            lines.append("## Approach Taken\n")
            lines.append(user_responses['approach'])
            lines.append("")

        # Decisions Made
        if 'decisions' in user_responses:
            lines.append("## Decisions Made\n")
            lines.append(user_responses['decisions'])
            lines.append("")

        # Alternatives Considered
        if 'alternatives' in user_responses:
            lines.append("## Alternatives Considered\n")
            lines.append(user_responses['alternatives'])
            lines.append("")

        # What Was Difficult/Surprising
        if 'challenges' in user_responses:
            lines.append("## Challenges & Surprises\n")
            lines.append(user_responses['challenges'])
            lines.append("")

        # Lessons Learned
        if 'lessons' in user_responses:
            lines.append("## Lessons Learned\n")
            lines.append(user_responses['lessons'])
            lines.append("")

        # What's Next
        if 'next_steps' in user_responses:
            lines.append("## What's Next\n")
            lines.append(user_responses['next_steps'])
            lines.append("")

        # Open Questions
        if 'open_questions' in user_responses and user_responses['open_questions'].strip():
            lines.append("## Open Questions\n")
            lines.append(user_responses['open_questions'])
            lines.append("")

        # Footer
        lines.append("---\n")
        lines.append(f"*Generated with interstitial-journal skill on {now.strftime('%Y-%m-%d at %H:%M')}*")

        return "\n".join(lines)

    def save_entry(
        self,
        content: str,
        slug_text: Optional[str] = None
    ) -> Path:
        """
        Save journal entry to file.

        Args:
            content: Markdown content to save
            slug_text: Text to use for filename slug (auto-extracted if None)

        Returns:
            Path to saved file
        """
        self.ensure_journal_dir()

        # Generate filename
        if slug_text is None:
            # Try to extract from first line or summary
            first_line = content.split('\n')[0].replace('#', '').strip()
            slug_text = extract_slug_from_summary(first_line)

        filename = generate_filename_slug(slug_text)
        file_path = self.journal_dir / filename

        # Handle collision (unlikely but possible)
        counter = 1
        while file_path.exists():
            base_name = filename.rsplit('.', 1)[0]
            filename = f"{base_name}-{counter}.md"
            file_path = self.journal_dir / filename
            counter += 1

        # Write file
        file_path.write_text(content, encoding='utf-8')

        return file_path

    def get_prompt_questions(self, context: Dict[str, Any]) -> List[Dict[str, str]]:
        """
        Get list of questions to ask user based on context.

        Args:
            context: Context dict from ContextDetector

        Returns:
            List of question dicts with 'key', 'question', and 'required' fields
        """
        questions = [
            {
                'key': 'title',
                'question': 'What would you title this work session?',
                'required': True
            },
            {
                'key': 'summary',
                'question': 'Provide a 2-3 sentence executive summary:',
                'required': True
            },
            {
                'key': 'problem',
                'question': 'What problem were you solving?',
                'required': True
            },
            {
                'key': 'approach',
                'question': 'What approach did you take? How did you solve it?',
                'required': True
            },
            {
                'key': 'decisions',
                'question': 'What key decisions did you make? Why?',
                'required': False
            },
            {
                'key': 'alternatives',
                'question': 'What alternatives did you consider? Why did you choose this path?',
                'required': False
            },
            {
                'key': 'challenges',
                'question': 'What was difficult or surprising?',
                'required': False
            },
            {
                'key': 'lessons',
                'question': 'What did you learn?',
                'required': True
            },
            {
                'key': 'next_steps',
                'question': 'What are the immediate next steps?',
                'required': True
            },
            {
                'key': 'open_questions',
                'question': 'Any open questions or uncertainties? (optional)',
                'required': False
            }
        ]

        return questions
