---
name: journal
description: Captures interstitial journal entries from work sessions by auto-detecting git commits or file changes and prompting for insights, decisions, and learnings
---

# Interstitial Journal

This skill enables you to capture comprehensive journal entries during natural breakpoints in your work. It automatically detects your context (git repository or regular filesystem), analyzes what changed, and guides you through documenting the human insights that matter: why you made decisions, what you learned, and what's next.

## Capabilities

- **Auto-Context Detection**: Automatically detects git repositories vs regular filesystem environments
- **Git Mode**: Reads recent commits, changed files, and diffs to understand what you've been working on
- **Filesystem Mode**: Identifies recently modified files and asks what's relevant to capture
- **Interactive Prompting**: Guides you through capturing the "why" behind your work with structured questions
- **Comprehensive Entries**: Generates detailed markdown journal entries with sections for problem, approach, decisions, lessons, and next steps
- **Atomic Notes**: Supports multiple journal entries per day, each capturing a specific work moment
- **Self-Contained**: All context embedded in the journal entry - no external links required
- **Universal Application**: Works for developers, business analysts, technical writers, researchers, and any knowledge worker

## Input Requirements

**Automatic Detection:**
- Git repository (optional): If present, analyzes commits from last 2 hours
- Recently modified files: Scans workspace for files modified in last 2 hours
- User context: Interactive prompts for insights

**User Provides:**
- What problem were you solving?
- Why this approach?
- What alternatives did you consider?
- What was surprising or difficult?
- What did you learn?
- What's next?

## Output Formats

Journal entries saved to `docs/journal/YYYY-MM-DD-HHMM-slug.md` with structure:

- **Executive Summary**: High-level overview of the work session
- **What Changed**: Git commits and file changes OR filesystem modifications
- **The Problem**: What you were solving and why it matters
- **Approach Taken**: How you solved it and key decisions
- **Decisions Made**: Choices with rationale and tradeoffs
- **Lessons Learned**: What worked, what didn't, surprises
- **What's Next**: Immediate next steps and open questions

## How to Use

Simply run the journal skill when you reach a natural breakpoint:

"Run the journal skill to capture this work session"

The skill will:
1. Auto-detect your environment (git or filesystem)
2. Show you what changed
3. Ask interactive questions
4. Generate a comprehensive journal entry
5. Save to `docs/journal/` with timestamp

## Scripts

- `detect_context.py`: Environment detection and change analysis
- `git_analyzer.py`: Git commit and diff analysis
- `filesystem_analyzer.py`: Recent file modification tracking
- `journal_generator.py`: Interactive prompting and markdown generation
- `slugify.py`: Filename slug generation from content

## Best Practices

1. **Capture often**: Run after completing a meaningful chunk of work (1-2 hours)
2. **Be specific**: Provide concrete details about decisions and tradeoffs
3. **Include alternatives**: Document paths not taken and why
4. **Note surprises**: Capture what was harder or easier than expected
5. **Self-contained**: Include all necessary context in the entry itself
6. **Multiple entries OK**: Create several per day for different work streams

## Limitations

- Requires file system access to detect changes
- Git analysis limited to last 2 hours by default (configurable)
- Interactive prompts require user input - not fully automated
- Quality depends on thoughtful user responses
- Diffs and commit messages provide context but not the "why"
