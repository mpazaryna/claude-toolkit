"""
Filesystem analysis module for interstitial journal skill.
Analyzes recently modified files for non-git environments.
"""

import os
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime, timedelta


class FilesystemAnalyzer:
    """Analyze filesystem changes for journal context."""

    def __init__(self, workspace_path: str = ".", time_window_hours: int = 2):
        """
        Initialize filesystem analyzer.

        Args:
            workspace_path: Path to workspace directory
            time_window_hours: How far back to look for changes
        """
        self.workspace_path = Path(workspace_path).resolve()
        self.time_window_hours = time_window_hours
        self.cutoff_time = datetime.now() - timedelta(hours=time_window_hours)

    def get_file_info(self, file_path: Path) -> Dict[str, Any]:
        """
        Get detailed information about a file.

        Args:
            file_path: Path to file

        Returns:
            Dict with path, size, modified time, file type
        """
        try:
            stat = file_path.stat()
            mtime = datetime.fromtimestamp(stat.st_mtime)

            # Determine file type category
            ext = file_path.suffix.lower()
            if ext in ['.py', '.js', '.ts', '.java', '.cpp', '.c', '.go', '.rs', '.swift']:
                file_type = 'code'
            elif ext in ['.md', '.txt', '.doc', '.docx', '.pdf']:
                file_type = 'documentation'
            elif ext in ['.json', '.yaml', '.yml', '.xml', '.csv', '.xlsx']:
                file_type = 'data'
            elif ext in ['.html', '.css', '.scss', '.sass']:
                file_type = 'web'
            else:
                file_type = 'other'

            return {
                'path': str(file_path.relative_to(self.workspace_path)),
                'size_bytes': stat.st_size,
                'modified': mtime.strftime('%Y-%m-%d %H:%M:%S'),
                'type': file_type,
                'timestamp': mtime
            }

        except (OSError, ValueError):
            return None

    def analyze_files(self, max_files: int = 50) -> List[Dict[str, Any]]:
        """
        Find and analyze recently modified files.

        Args:
            max_files: Maximum number of files to analyze

        Returns:
            List of file info dicts
        """
        modified_files = []

        # Directories to skip
        skip_dirs = {
            '.git', '__pycache__', 'node_modules', 'venv', 'env',
            '.venv', 'dist', 'build', '.cache', '.pytest_cache',
            '.mypy_cache', '.tox', 'coverage', '.idea', '.vscode'
        }

        # File patterns to skip
        skip_patterns = {
            '.pyc', '.pyo', '.pyd', '.so', '.dll', '.dylib',
            '.class', '.o', '.obj', '.exe', '.tmp', '.temp',
            '.log', '.cache', '.DS_Store', 'Thumbs.db'
        }

        try:
            for root, dirs, files in os.walk(self.workspace_path):
                # Skip hidden and build directories
                root_path = Path(root)

                # Remove skip directories from dirs list (modifies in-place)
                dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith('.')]

                for file in files:
                    # Skip hidden files and temp files
                    if file.startswith('.'):
                        continue
                    if any(file.endswith(pattern) for pattern in skip_patterns):
                        continue

                    file_path = root_path / file
                    file_info = self.get_file_info(file_path)

                    if file_info and file_info['timestamp'] >= self.cutoff_time:
                        modified_files.append(file_info)

            # Sort by modification time (most recent first)
            modified_files.sort(key=lambda x: x['timestamp'], reverse=True)

            # Remove timestamp from output and limit results
            return [
                {
                    'path': f['path'],
                    'size_bytes': f['size_bytes'],
                    'modified': f['modified'],
                    'type': f['type']
                }
                for f in modified_files[:max_files]
            ]

        except Exception:
            return []

    def group_by_type(self, files: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        """
        Group files by their type category.

        Args:
            files: List of file info dicts

        Returns:
            Dict mapping file type to list of paths
        """
        grouped = {}

        for file_info in files:
            file_type = file_info['type']
            if file_type not in grouped:
                grouped[file_type] = []
            grouped[file_type].append(file_info['path'])

        return grouped

    def get_stats(self, files: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Calculate statistics about modified files.

        Args:
            files: List of file info dicts

        Returns:
            Dict with counts and totals
        """
        if not files:
            return {
                'total_files': 0,
                'total_size_bytes': 0,
                'by_type': {}
            }

        total_size = sum(f['size_bytes'] for f in files)
        by_type = {}

        for file_info in files:
            file_type = file_info['type']
            if file_type not in by_type:
                by_type[file_type] = 0
            by_type[file_type] += 1

        return {
            'total_files': len(files),
            'total_size_bytes': total_size,
            'by_type': by_type
        }

    def analyze(self) -> Dict[str, Any]:
        """
        Perform complete filesystem analysis.

        Returns:
            Dict with files, grouped files, and stats
        """
        files = self.analyze_files()
        grouped = self.group_by_type(files)
        stats = self.get_stats(files)

        return {
            'files': files,
            'grouped_by_type': grouped,
            'stats': stats
        }
