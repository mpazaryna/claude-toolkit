"""
Context detection module for interstitial journal skill.
Determines whether we're in a git repository and what changes have occurred.
"""

import subprocess
import os
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta


class ContextDetector:
    """Detect work context (git vs filesystem) and recent changes."""

    def __init__(self, workspace_path: str = ".", time_window_hours: int = 2):
        """
        Initialize context detector.

        Args:
            workspace_path: Path to workspace directory (defaults to current)
            time_window_hours: How far back to look for changes (default: 2 hours)
        """
        self.workspace_path = Path(workspace_path).resolve()
        self.time_window_hours = time_window_hours
        self.cutoff_time = datetime.now() - timedelta(hours=time_window_hours)

    def is_git_repo(self) -> bool:
        """Check if current directory is a git repository."""
        try:
            result = subprocess.run(
                ['git', 'rev-parse', '--git-dir'],
                cwd=self.workspace_path,
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except (subprocess.SubprocessError, FileNotFoundError):
            return False

    def has_recent_commits(self) -> bool:
        """Check if there are commits within the time window."""
        try:
            since_time = self.cutoff_time.strftime('%Y-%m-%d %H:%M:%S')
            result = subprocess.run(
                ['git', 'log', f'--since={since_time}', '--oneline'],
                cwd=self.workspace_path,
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.returncode == 0 and len(result.stdout.strip()) > 0
        except (subprocess.SubprocessError, FileNotFoundError):
            return False

    def get_recently_modified_files(self, max_files: int = 20) -> List[Dict[str, Any]]:
        """
        Find files modified within time window.

        Args:
            max_files: Maximum number of files to return

        Returns:
            List of dicts with file path and modification time
        """
        modified_files = []

        try:
            for root, _, files in os.walk(self.workspace_path):
                # Skip hidden directories and common build artifacts
                root_path = Path(root)
                if any(part.startswith('.') for part in root_path.parts):
                    continue
                if any(part in ['node_modules', '__pycache__', 'venv', 'dist', 'build']
                       for part in root_path.parts):
                    continue

                for file in files:
                    # Skip hidden files and common temp files
                    if file.startswith('.') or file.endswith(('.pyc', '.tmp', '.log')):
                        continue

                    file_path = root_path / file
                    try:
                        mtime = datetime.fromtimestamp(file_path.stat().st_mtime)

                        if mtime >= self.cutoff_time:
                            relative_path = file_path.relative_to(self.workspace_path)
                            modified_files.append({
                                'path': str(relative_path),
                                'modified': mtime.strftime('%Y-%m-%d %H:%M:%S'),
                                'timestamp': mtime
                            })
                    except (OSError, ValueError):
                        continue

            # Sort by modification time (most recent first)
            modified_files.sort(key=lambda x: x['timestamp'], reverse=True)

            # Remove timestamp from output and limit results
            return [
                {'path': f['path'], 'modified': f['modified']}
                for f in modified_files[:max_files]
            ]

        except Exception:
            return []

    def detect_context(self) -> Dict[str, Any]:
        """
        Detect current work context.

        Returns:
            Dict with context information:
            - mode: 'git', 'filesystem', or 'manual'
            - has_git: bool
            - has_commits: bool
            - recent_files: list of modified files
        """
        is_git = self.is_git_repo()
        has_commits = False

        if is_git:
            has_commits = self.has_recent_commits()

        recent_files = self.get_recently_modified_files()

        # Determine mode
        if is_git and has_commits:
            mode = 'git'
        elif recent_files:
            mode = 'filesystem'
        else:
            mode = 'manual'

        return {
            'mode': mode,
            'has_git': is_git,
            'has_commits': has_commits,
            'recent_files': recent_files,
            'time_window_hours': self.time_window_hours
        }
